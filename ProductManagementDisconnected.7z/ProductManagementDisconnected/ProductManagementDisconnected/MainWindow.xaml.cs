﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Configuration;

namespace ProductManagementDisconnected
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;
        SqlConnection connection = new SqlConnection(ConnectionString);

        SqlCommand command = new SqlCommand();
        DataSet dataSet = new DataSet();
        SqlDataAdapter adapter = new SqlDataAdapter();
        public MainWindow()
        {
            InitializeComponent();
        }
        public void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                command.CommandText = "SELECT * FROM Product_46022923";
                adapter = new SqlDataAdapter(command.CommandText, connection);
          
                adapter.Fill(dataSet);
                dg.DataContext = dataSet.Tables[0];
            }
            catch(SqlException exception)
            {
                MessageBox.Show("Exception Occurred" + exception.Message);
            }
        }

        private void Add_Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                 DataRow newRow = dataSet.Tables[0].NewRow();
                newRow[0] = txtProductId.Text;
                newRow[1] = txtProductName.Text;
                newRow[2] = txtPrice.Text;
                newRow[3] = txtQuantity.Text;



                dataSet.Tables[0].Rows.Add(newRow);
                MessageBox.Show("Product Added to Dataset");
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Occured" + exception.Message);
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            int productId = int.Parse(txtProductId.Text);
            for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
            {
                int currentRowProductId = int.Parse(dataSet.Tables[0].Rows[i][0].ToString());
                if(currentRowProductId==productId)
                {
                    MessageBox.Show("Product Found!!");
                    txtProductName.Text = dataSet.Tables[0].Rows[i][1].ToString();
                    txtPrice.Text = dataSet.Tables[0].Rows[i][2].ToString();
                    txtQuantity.Text = dataSet.Tables[0].Rows[i][3].ToString();
                    break;
                }
            }
           
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int productId = int.Parse(txtProductId.Text);
            for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
            {
                int currentRowProductId = int.Parse(dataSet.Tables[0].Rows[i][0].ToString());
                if (currentRowProductId == productId)
                {
                    dataSet.Tables[0].Rows[i][1] = txtProductName.Text;
                    dataSet.Tables[0].Rows[i][2] = txtPrice.Text;
                    dataSet.Tables[0].Rows[i][3]= txtQuantity.Text;

                    MessageBox.Show("Product Updated!!");
                    break;
                }
            }
        }

        private void btnWriteToDatabase_Click(object sender, RoutedEventArgs e)
        {
            SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(adapter);
            adapter.UpdateCommand = sqlCommandBuilder.GetUpdateCommand();
            adapter.Update(dataSet);
            MessageBox.Show("All changes returned to Data Base!!!!");
        }
    }
}
