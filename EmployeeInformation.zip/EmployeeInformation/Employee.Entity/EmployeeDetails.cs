﻿using System;

namespace Employee.Entity
{
    [Serializable]
    public class EmployeeDetails
    {

        public string employeeName { get; set; }
        public int employeeId { get; set; }
        public string employeeEmailId { get; set; }
        public long employeePhoneNumber { get; set; }
        public string employeeAddress { get; set; }
        public string employeeDateOfBirth { get; set; }
        public string employeeDateOfJoining { get; set; }
        public string employeeDepartment { get; set; }
        public string employeeProject { get; set; }
        public string employeeRole { get; set; }
        public int employeeDepartmentId { get; set; }
        public int employeeProjectId { get; set; }
        public int employeeRoleId { get; set; }

       
    }

}
