﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Employee.Entity
{
    /**********Department class entities*********/
    [Serializable]
    public class DepartmentEntity:EmployeeEntity
    {
        public int departmentId { get; set; }
        public string departmentName { get; set; }
        public string departmentDescription { get; set; }

    }
}
