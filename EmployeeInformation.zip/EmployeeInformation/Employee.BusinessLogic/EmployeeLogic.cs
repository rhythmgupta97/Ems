﻿using System;
using Employee.Entity;
using Employee.DataAccess;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Linq;
namespace Employee.BusinessLogic
{
    public class EmployeeLogic
    {
     /*****************Validation of data******************************/
        public static bool CheckEmployee(EmployeeDetails employee)
        {
            //var emailCheck = new Regex(@"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.com\b");
            //var dateCheck = new Regex(@"(0[1-9]|[12][0-9]|3[01])[- \.](0[1-9]|1[012])[- \.](19|20\d\d)");
            //var phoneCheck = new Regex(@"([7-9])([0-9]{9})");
            //var nameCheck = new Regex(@"([A-Z]{1})([a-z]{1,25})");
            //if (employee.employeeName.Length>0 && nameCheck.IsMatch(employee.employeeName))
            //   {
            //    List<EmployeeDetails> employees=DatabaseOperation.ListDeSerializer();
            //    int maxId=employee.Math.Max(t => t.Age);
            //    return true;
            //   }

            //   if (employee.employeeId>0)
            //   {

            //       return true;
            //   }

            //   if (employee.employeeEmailId.Equals("ds334294@gmail.com"))
            //   {
            //       return true;
            //   }

            //   if (employee.employeePhoneNumber.Equals("9068351032"))
            //   {
            //       return true;
            //   }
            //   if (employee.employeeAddress.Equals("rishikesh"))
            //   {
            //       return true;
            //   }

            //   if (employee.employeeDateOfBirth.Equals("23/12/1997"))
            //   {
            //       return true;
            //   }

            //   if (employee.employeeDateOfJoining.Equals("23/01/2020"))
            //   {
            //       return true;
            //   }

            //   if (employee.employeeDepartment.Equals("cs"))
            //   {
            //       return true;
            //   }

            //   if (employee.employeeProject.Equals("ems"))
            //   {
            //       return true;
            //   }

            //   if (employee.employeeRole.Equals("developer"))
            //   {
            //       return true;
            //   }


               //if (employee.employeeDepartmentId==1)
               //{
               //    return true;
               //}

               //if (employee.employeeProjectId==1)
               //{
               //    return true;
               //}

               //if (employee.employeeRoleId==1)
               //{
               //    return true;
               //}
               //else
               //{
               //    return false;
               //}
            return true;
        }

        /*****************Calling to checkEmployee than calling to dataaccess******************************/
        public static bool AddEmployee(EmployeeDetails employee)
        {


            if (CheckEmployee(employee))
            {
                DatabaseOperation.ListSerializer(employee);
                return true;
            }
            else
            {
                return false;
            }

        }

        /****************get the all list of employee*********************/
        public List<EmployeeDetails> GetAllProducts()
        {
            return DatabaseOperation.ListDeSerializer();

        }

    }
}
