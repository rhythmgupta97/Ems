﻿using System;
using Employee.Entity;
using Employee.DataAccess;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Linq;
namespace Employee.BusinessLogic
{
    public class EmployeeLogic
    {
     /*****************Validation of data******************************/
        public static bool CheckEmployee(EmployeeDetails employee)
        {
            var emailCheck = new Regex(@"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.com\b");
            var dateCheck = new Regex(@"(0[1-9]|[12][0-9]|3[01])[- \.\/\-](0[1-9]|1[012])[- \.\/\-](19|20\d\d)");
            var phoneCheck = new Regex(@"\b([7-9])([0-9]{9})\b");
            var nameCheck = new Regex(@"([A-Z]{1})([a-z]{1,25})");
            if (nameCheck.IsMatch(employee.employeeName) && emailCheck.IsMatch(employee.employeeEmailId)&& phoneCheck.IsMatch(employee.employeePhoneNumber.ToString())
                && employee.employeeAddress.Length > 0 && dateCheck.IsMatch(employee.employeeDateOfBirth) && dateCheck.IsMatch(employee.employeeDateOfJoining)
                && employee.employeeDepartment.Length > 0 && employee.employeeProject.Length > 0 && employee.employeeRole.Length > 0)
            {    
               return true;
            }

            // else if (emailCheck.IsMatch (employee.employeeEmailId))
            //{
            //    return true;
            //}

            //else if(phoneCheck.IsMatch(employee.employeePhoneNumber.ToString()))
            //{
            //    return true;
            //}
            //else if (employee.employeeAddress.Length>0)
            //{
            //    return true;
            //}

            //else if(dateCheck.IsMatch(employee.employeeDateOfBirth))
            //{
            //    return true;
            //}

            //else if (dateCheck.IsMatch(employee.employeeDateOfJoining))
            //{
            //    return true;
            //}

            //else if(employee.employeeDepartment.Length>0)
            //{
            //    return true;
            //}

            //else if(employee.employeeProject.Length>0)
            //{
            //    return true;
            //}

            //else if(employee.employeeRole.Length>0)
            //{
            //    return true;
            //}


            //if (employee.employeeDepartmentId == 1)
            //{
            //    return true;
            //}

            //if (employee.employeeProjectId==1)
            //{
            //    return true;
            //}

            //if (employee.employeeRoleId==1)
            //{
            //    return true;
            //}
            else
            {
                return false;
            }
           // return true;
        }

        /*****************Calling to checkEmployee than calling to dataaccess******************************/
        public static bool AddEmployee(EmployeeDetails employee)
        {


            if (CheckEmployee(employee))
            {
                DatabaseOperation.ListSerializer(employee);
                return true;
            }
            else
            {
                return false;
            }

        }

        /****************get the all list of employee*********************/
        public List<EmployeeDetails> GetAllProducts()
        {
            return DatabaseOperation.ListDeSerializer();

        }

    }
}
