﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee.Entity;
using Employee.BusinessLogic;
namespace Employee.Presentation
{
    class EmployeeInformation
    {
        public static EmployeeLogic employeeLogic = new EmployeeLogic();
        public static List<EmployeeEntity> EmployeeList = new List<EmployeeEntity>();
        static void Main(string[] args)
        {
            int choice;

            while (true)
            {
                Console.WriteLine("Enter your Choice");
                Console.WriteLine("1. Add");
                Console.WriteLine("2. Display");
                Console.WriteLine("3. Search");
                Console.WriteLine("4. Search by Category");
                Console.WriteLine("5. Exit");

                choice = Convert.ToInt32(Console.ReadLine());
                //menu driven in which you do the operation
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Enter your Choice!!");
                        
                        Console.WriteLine("1. Add Department Details:");
                        Console.WriteLine("2. Add Project Details:");
                        Console.WriteLine("3. Add Role Details:");
                        Console.WriteLine("4. Add Employee Details:");
                        Console.WriteLine("5. Exit");
                        int inputIn = Convert.ToInt32(Console.ReadLine());
                        switch (inputIn)
                        {
                            
                            case 1:
                                if (EmployeeLogic.AddDepartment(GetDepartmentData()))                               
                                    Console.WriteLine("Department information is added Successfully");
                                else
                                    Console.WriteLine("Error in adding Department information!!!");
                                break;
                            
                            case 2:
                                if (EmployeeLogic.AddProject(GetProjectData()))                                
                                    Console.WriteLine("Project information is added Successfully");
                                else
                                    Console.WriteLine("Error in adding Project information!!!");
                                break;
                            
                            case 3:
                                if (EmployeeLogic.AddRole(GetRoleData()))                                
                                    Console.WriteLine("Role information is added Successfully");
                                  else
                                    Console.WriteLine("Error in adding Role information!!!");
                                break;
                          
                            case 4:
                                if (EmployeeLogic.AddEmployee(GetEmployeeData()))
                                    Console.WriteLine("Employee information is added Successfully");
                                else
                                    Console.WriteLine("Error in adding Employee information!!!");
                                 break;
                           
                            case 5:
                                Environment.Exit(0);
                                break;
                            default:
                                Console.WriteLine("Enter the valid input!!!");
                                break;
                        }
                        break;

                    case 2:
                        Console.WriteLine("Enter your Choice!!");

                        Console.WriteLine("1. Display Department Details:");
                        Console.WriteLine("2. Display Project Details:");
                        Console.WriteLine("3. Display Role Details:");
                        Console.WriteLine("4. Display Employee Details:");
                        Console.WriteLine("5. Exit");
                        int inputOut = Convert.ToInt32(Console.ReadLine());
                        switch (inputOut)
                        {

                            case 1:
                               DisplayDepartment(employeeLogic.GetAllDepartment());
                                break;

                            case 2:
                                DisplayProject(employeeLogic.GetAllProject());
                                break;

                            case 3:
                                DisplayRole(employeeLogic.GetAllRole());
                                break;

                            case 4:
                                DisplayEmployee(employeeLogic.GetAllEmployee());
                                break;

                            case 5:
                                Environment.Exit(0);
                                break;
                            default:
                                Console.WriteLine("Enter the valid input!!!");
                                break;
                        }
                        break;
                    /*   case 3:
                           Console.WriteLine("Enter the product id you want to search:");
                           int search = Convert.ToInt32(Console.ReadLine());
                           Entity searchedProduct = business.SearchProductById(search);
                           if (searchedProduct != null)
                           {
                               Console.WriteLine($"{searchedProduct.productId}  {searchedProduct.productName}   {searchedProduct.productPrice}  {searchedProduct.productCategory}");
                           }
                           else
                           {

                               Console.WriteLine($"Product with the specified id:{search} doesnotpresent!");
                           }

                           break;
                       case 4:
                           Console.WriteLine("Enter the product category you want to search:");
                           string categorysearch = Console.ReadLine();
                           List<Entity> categorySearchList = productList.FindAll(val => val.productCategory.Equals(categorysearch));
                           Console.WriteLine("search product by category name get:");
                           Console.WriteLine("--------------------------");
                           if (categorySearchList.Count > 0)
                           {
                               foreach (Entity listSearch1 in categorySearchList)
                               {
                                   Console.WriteLine($"{listSearch1.productId}  {listSearch1.productName}   {listSearch1.productPrice}  {listSearch1.productCategory}");
                               }
                           }
                           else
                           {
                               Console.WriteLine("No search found");
                           }
                           break;*/
                    case 5:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }

            }
        }

        /*****************Enter employee details******************************/
        public static EmployeeEntity GetEmployeeData()
        {

            EmployeeEntity employee = new EmployeeEntity();
           


         
            Console.WriteLine("Enter Name:");
            employee.employeeName = Console.ReadLine();
            Console.WriteLine("Enter EmailId:");
            employee.employeeEmailId = Console.ReadLine();
            Console.WriteLine("Enter PhoneNumber:");
            employee.employeePhoneNumber = Convert.ToInt64(Console.ReadLine());
            Console.WriteLine("Enter Address:");
            employee.employeeAddress = Console.ReadLine();
            Console.WriteLine("Enter DateOfBirth:");
            employee.employeeDateOfBirth = Console.ReadLine();
            Console.WriteLine("Enter DateOfJoining:");
            employee.employeeDateOfJoining = Console.ReadLine();
            Console.WriteLine("Enter Department ID:");
            employee.employeeDepartmentId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Project ID:");
            employee.employeeProjectId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Role ID:");
            employee.employeeRoleId = Convert.ToInt32(Console.ReadLine());
            return employee;
        }
        /*****************Enter Department details******************************/
        public static DepartmentEntity GetDepartmentData()
        {

            DepartmentEntity department = new DepartmentEntity();
            //Console.WriteLine("Enter Department Id:");
            //department.employeeDepartmentId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Department Name:");
            department.departmentName = Console.ReadLine();
            Console.WriteLine("Enter Department Description:");
            department.departmentDescription = Console.ReadLine();
            return department;
        }
        /*****************Enter Project details******************************/
        public static ProjectEntity GetProjectData()
        {
            ProjectEntity project = new ProjectEntity();
            //Console.WriteLine("Enter Project Id:");
            //project.projectId= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Project Name:");
            project.projectName =Console.ReadLine();
            Console.WriteLine("Enter Project Description:");
            project.projectDescription =Console.ReadLine();
            Console.WriteLine("Enter Department Id:");
            project.employeeDepartmentId = Convert.ToInt32(Console.ReadLine());
            return project;
        }
        /*****************Enter employee details******************************/
        public static RoleEntity GetRoleData()
        {
            RoleEntity role = new RoleEntity();
            //Console.WriteLine("Enter Role Id:");
            //role.roleId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Role Name:");
            role.roleName = Console.ReadLine();
            Console.WriteLine("Enter Role description:");
            role.roleDescription = Console.ReadLine();

            return role;
        }


        /***************** Displaying all record of employees ******************************/
        public static void DisplayEmployee(List<EmployeeEntity> employees)
        {

            Console.WriteLine("***********************************************************************************************************************");
            Console.WriteLine("Name" + "  " + "Id" + "   "+"KinId"+"  "+"EmailId" + "  " + "Ph.Number" + "  " + "Address" + "  " + "DateOfBirth" + "  " + "DateOfJoining"
                + "  " + "DepartmentID" + "  " + "ProjectID" + "  " + "RoleID");
            Console.WriteLine("************************************************************************************************************************");
            foreach (EmployeeEntity employee in employees)
            {
                Console.WriteLine($"{employee.employeeName}  {employee.employeeId}  {employee.employeeEmailId}   {employee.employeePhoneNumber}" +
                    $" {employee.employeeAddress}  {employee.employeeDateOfBirth}  {employee.employeeDateOfJoining} " +
                    $"   {employee.employeeDepartmentId}  {employee.employeeProjectId}  {employee.employeeRoleId}");
            }
            Console.WriteLine("************************************************************************************************************************");
            Console.ReadKey();

        }
        /***************** Displaying all record of Department ******************************/
        public static void DisplayDepartment(List<DepartmentEntity> departments)
        {

            Console.WriteLine("*****************************Department Record***********************");
            Console.WriteLine("Name" + "  " + "Id" + "  " + "Description");
            Console.WriteLine("**********************************************************************");
            foreach (DepartmentEntity department in departments)
            {
                Console.WriteLine($"{department.departmentName}  {department.departmentId}  {department.departmentDescription}");
            }
            Console.WriteLine("************************************************************************");
            Console.ReadKey();

        }
        /***************** Displaying all record of Projects ******************************/
        public static void DisplayProject(List<ProjectEntity> projects)
        {
            Console.WriteLine("*****************************Project Record***************************");
            Console.WriteLine("Name" + "  " + "ProjectId" + "  " + "Description"+"  "+"DepartmentId");
            Console.WriteLine("***********************************************************************");
            foreach (ProjectEntity project in projects)
            {
                Console.WriteLine($"{project.projectName}  {project.projectId}  {project.projectDescription}  {project.employeeDepartmentId}");
            }
            Console.WriteLine("***********************************************************************");
            Console.ReadKey();

        }
        /***************** Displaying all record of Roles ******************************/
        public static void DisplayRole(List<RoleEntity> roles)
        {
            Console.WriteLine("*******************************Role Record***************************");
            Console.WriteLine("Name" + "  " + "RoleId" + "  " + "Description");
            Console.WriteLine("**********************************************************************");
            foreach (RoleEntity role in roles)
            {
                Console.WriteLine($"{role.roleName}  {role.roleId}  {role.roleDescription}");
            }
            Console.WriteLine("**********************************************************************");
            Console.ReadKey();

        }

    }
}
