﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee.Entity;
using Employee.BusinessLogic;
namespace Employee.Presentation
{
    class EmployeeInformation
    {
        public static EmployeeLogic employeeLogic = new EmployeeLogic();
        public static List<EmployeeDetails> EmployeeList = new List<EmployeeDetails>();
        static void Main(string[] args)
        {
            int choice;

            while (true)
            {
                Console.WriteLine("Enter your Choice");
                Console.WriteLine("1. Add");
                Console.WriteLine("2. Display");
                Console.WriteLine("3. Search by id");
                Console.WriteLine("4. Search by Category");
                Console.WriteLine("5. Exit");

                choice = Convert.ToInt32(Console.ReadLine());
                //menu driven in which you do the operation
                switch (choice)
                {
                    case 1:
                        if (EmployeeLogic.AddEmployee(GetEmployeeData()))
                        {
                            Console.WriteLine("Product information is added Successfully");

                        }
                        else
                        {
                            Console.WriteLine("Error in adding product info!");
                        }
                        break;
                    case 2:
                        DisplayEmployee(employeeLogic.GetAllProducts());
                        break;
                    /*   case 3:
                           Console.WriteLine("Enter the product id you want to search:");
                           int search = Convert.ToInt32(Console.ReadLine());
                           Entity searchedProduct = business.SearchProductById(search);
                           if (searchedProduct != null)
                           {
                               Console.WriteLine($"{searchedProduct.productId}  {searchedProduct.productName}   {searchedProduct.productPrice}  {searchedProduct.productCategory}");
                           }
                           else
                           {

                               Console.WriteLine($"Product with the specified id:{search} doesnotpresent!");
                           }

                           break;
                       case 4:
                           Console.WriteLine("Enter the product category you want to search:");
                           string categorysearch = Console.ReadLine();
                           List<Entity> categorySearchList = productList.FindAll(val => val.productCategory.Equals(categorysearch));
                           Console.WriteLine("search product by category name get:");
                           Console.WriteLine("--------------------------");
                           if (categorySearchList.Count > 0)
                           {
                               foreach (Entity listSearch1 in categorySearchList)
                               {
                                   Console.WriteLine($"{listSearch1.productId}  {listSearch1.productName}   {listSearch1.productPrice}  {listSearch1.productCategory}");
                               }
                           }
                           else
                           {
                               Console.WriteLine("No search found");
                           }
                           break;*/
                    case 5:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }

            }
        }

        /***************** To assign value to the all field ******************************/
        public static EmployeeDetails GetEmployeeData()
        {

            EmployeeDetails employee = new EmployeeDetails();
            Console.WriteLine("Enter Name:");
            employee.employeeName = Console.ReadLine();
            //Console.WriteLine("Enter ID:");
            //employee.employeeId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter EmailId:");
            employee.employeeEmailId = Console.ReadLine();
            Console.WriteLine("Enter PhoneNumber:");
            employee.employeePhoneNumber = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Address:");
            employee.employeeAddress = Console.ReadLine();
            Console.WriteLine("Enter employeeDateOfBirth:");
            employee.employeeDateOfBirth = Console.ReadLine();
            Console.WriteLine("Enter employeeDateOfJoining:");
            employee.employeeDateOfJoining = Console.ReadLine();
            Console.WriteLine("Enter employeeDepartment:");
            employee.employeeDepartment = Console.ReadLine();
            Console.WriteLine("Enter employeeProject:");
            employee.employeeProject = Console.ReadLine();
            Console.WriteLine("Enter employeeRole:");
            employee.employeeRole = Console.ReadLine();
            Console.WriteLine("Enter employeeDepartmentId:");
            employee.employeeDepartmentId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter employeeProjectId:");
            employee.employeeProjectId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter employeeRoleId:");
            employee.employeeRoleId = Convert.ToInt32(Console.ReadLine());

            return employee;
        }

        ///***************** Displaying the all record of employees ******************************/
        public static void DisplayEmployee(List<EmployeeDetails> employees)
        {

            Console.WriteLine("*************************************************************************");
            Console.WriteLine("Name" + "  " + "Id" + "  " + "EmailId" + "  " + "Ph.Number" + "  " + "Address" + "  " + "DateOfBirth" + "  " + "DateOfJoining"
                + "  " + "Department" + "  " + "Project" + "  " + "Role" + "  " + "DId" + " " + "PID" + "  " + "RID");
            Console.WriteLine("*************************************************************************");
            foreach (EmployeeDetails employee in employees)
            {
                Console.WriteLine($"{employee.employeeName}  {employee.employeeId}  {employee.employeeEmailId}   {employee.employeePhoneNumber}" +
                    $" {employee.employeeAddress}  {employee.employeeDateOfBirth}  {employee.employeeDateOfJoining}  {employee.employeeDepartment}" +
                    $"  {employee.employeeProject}  {employee.employeeRole}  {employee.employeeDepartmentId}  {employee.employeeProjectId}  {employee.employeeRoleId}");
            }
            Console.ReadKey();

        }

    }
}
