﻿using System;
using Employee.Entity;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
namespace Employee.DataAccess
{
    public class DatabaseOperation
    {
     public static List<EmployeeDetails> employees = new List<EmployeeDetails>();
        public static void ListSerializer(EmployeeDetails employee)
        {
            string path = @"C:\Users\DSINGH58\Desktop\Deepak Singh\Sprint1\EmployeeInformation\DataBase\EmployeeList.txt";

            BinaryFormatter formatter = new BinaryFormatter();
          
            if (File.Exists(path))
            {
                int MaxEmployeeId = 0;
             
                employees = ListDeSerializer();
                if (employees.Count > 0)
                {

                    foreach (EmployeeDetails emp in employees)
                    {
                        if (emp.employeeId > MaxEmployeeId)
                            MaxEmployeeId = emp.employeeId;
                    }
                    employee.employeeId = MaxEmployeeId + 1;
                   
                    employees.Add(employee);
                    Stream stream = File.Open(path, FileMode.Open, FileAccess.Write);
                    formatter.Serialize(stream, employees);
                    stream.Close();
                }
                /**************************************/
               

                
            }
            else {
               employee.employeeId = 1;  //initial id of employee

                employees.Add(employee);
                
                Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);         
            formatter.Serialize(stream, employees);
                stream.Close();
            }
           
        }

        public static List<EmployeeDetails> ListDeSerializer()
            
        {
            string path = @"C:\Users\DSINGH58\Desktop\Deepak Singh\Sprint1\EmployeeInformation\DataBase\EmployeeList.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<EmployeeDetails> employee = (List<EmployeeDetails>)formatter.Deserialize(stream);
            stream.Close();
            return employee;
        }

       

    }
}
