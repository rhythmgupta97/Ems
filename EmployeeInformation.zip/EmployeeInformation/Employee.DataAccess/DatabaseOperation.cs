﻿using System;
using Employee.Entity;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
namespace Employee.DataAccess
{
    public class DatabaseOperation
    {
     public static List<EmployeeEntity> employees = new List<EmployeeEntity>();
     public static List<DepartmentEntity> departments = new List<DepartmentEntity>();
     public static List<ProjectEntity> projects = new List<ProjectEntity>();
     public static List<RoleEntity> roles = new List<RoleEntity>();
/************************************** Seralizing Employee Data **************************************************/
        public static void EmployeeListSerializer(EmployeeEntity employee)
        {
            string path = @"C:\Users\DSINGH58\Desktop\Deepak Singh\Sprint1\EmployeeInformation\DataBase\Employees.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            if (File.Exists(path))
            {
                int MaxEmployeeId = 0;
             
                employees = EmployeeListDeSerializer();
                if (employees.Count > 0)
                {

                    foreach (EmployeeEntity emp in employees)
                    {
                        if (emp.employeeId > MaxEmployeeId)
                            MaxEmployeeId = emp.employeeId;
                    }
                    employee.employeeId = MaxEmployeeId + 1;
                    employee.employeeKinId = "KIN" + MaxEmployeeId+1;                   
                    employees.Add(employee);
                    Stream stream = File.Open(path, FileMode.Open, FileAccess.Write);
                    formatter.Serialize(stream, employees);
                    stream.Close();
                }
                
            }
            else {
               employee.employeeId = 1;  //Initial id of Employee

                employees.Add(employee);
                
                Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);         
            formatter.Serialize(stream, employees);
                stream.Close();
            }
           
        }

        /************************************** Seralizing Department Data **************************************************/
        public static void DepartmentListSerializer(DepartmentEntity department)
        {
            string path = @"C:\Users\DSINGH58\Desktop\Deepak Singh\Sprint1\EmployeeInformation\DataBase\Departments.txt";

            BinaryFormatter formatter = new BinaryFormatter();

            if (File.Exists(path))
            {
                int MaxDepartmentId = 100;

                departments = DepartmentListDeSerializer();
                if (departments.Count > 0)
                {
                    foreach (DepartmentEntity dpt in departments)
                    {
                        if (dpt.departmentId > MaxDepartmentId)
                            MaxDepartmentId = dpt.departmentId;
                    }
                    department.departmentId = MaxDepartmentId + 1;

                    departments.Add(department);
                    Stream stream = File.Open(path, FileMode.Open, FileAccess.Write);
                    formatter.Serialize(stream, departments);
                    stream.Close();
                }

            }
            else
            {
                department.departmentId = 100;  //Initial id of Department
                departments.Add(department);
                Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);
                formatter.Serialize(stream, departments);
                stream.Close();
            }

        }

        /************************************** Seralizing Project Data **************************************************/
        public static void ProjectListSerializer(ProjectEntity project)
        {
            string path = @"C:\Users\DSINGH58\Desktop\Deepak Singh\Sprint1\EmployeeInformation\DataBase\Projects.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            if (File.Exists(path))
            {
                int MaxProjectId = 1000;
                projects = ProjectListDeSerializer();
                if (projects.Count > 0)
                {
                    foreach (ProjectEntity pro in projects)
                    {
                        if (pro.projectId > MaxProjectId)
                            MaxProjectId = pro.projectId;
                    }
                    project.projectId = MaxProjectId + 1;
                    projects.Add(project);
                    Stream stream = File.Open(path, FileMode.Open, FileAccess.Write);
                    formatter.Serialize(stream, projects);
                    stream.Close();
                }
            }
            else
            {
                project.projectId = 1000;  //Initial id of Project
                projects.Add(project);
                Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);
                formatter.Serialize(stream, projects);
                stream.Close();
            }

        }

        /************************************** Seralizing Role Data **************************************************/
        public static void RoleListSerializer(RoleEntity role)
        {
            string path = @"C:\Users\DSINGH58\Desktop\Deepak Singh\Sprint1\EmployeeInformation\DataBase\Roles.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            if (File.Exists(path))
            {
                int MaxRoleId = 2000;
                roles = RoleListDeSerializer();
                if (roles.Count > 0)
                {
                    foreach (RoleEntity rol in roles)
                    {
                        if (rol.roleId > MaxRoleId)
                            MaxRoleId = rol.roleId;
                    }
                    role.roleId = MaxRoleId + 1;
                    roles.Add(role);
                    Stream stream = File.Open(path, FileMode.Open, FileAccess.Write);
                    formatter.Serialize(stream, roles);
                    stream.Close();
                }
            }
            else
            {
                role.roleId = 2000;  //Initial id of Role
                roles.Add(role);
                Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);
                formatter.Serialize(stream, roles);
                stream.Close();
            }

        }

        /******************************* Desirializing Employee Data*******************************************/
        public static List<EmployeeEntity> EmployeeListDeSerializer()
            
        {
            string path = @"C:\Users\DSINGH58\Desktop\Deepak Singh\Sprint1\EmployeeInformation\DataBase\Employees.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<EmployeeEntity> employee = (List<EmployeeEntity>)formatter.Deserialize(stream);
            stream.Close();
            return employee;
        }

        /******************************* Desirializing Department Data*******************************************/
        public static List<DepartmentEntity> DepartmentListDeSerializer()

        {
            string path = @"C:\Users\DSINGH58\Desktop\Deepak Singh\Sprint1\EmployeeInformation\DataBase\Departments.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<DepartmentEntity> department = (List<DepartmentEntity>)formatter.Deserialize(stream);
            stream.Close();
            return department;
        }
        /******************************* Desirializing  Project Data*******************************************/
        public static List<ProjectEntity> ProjectListDeSerializer()

        {
            string path = @"C:\Users\DSINGH58\Desktop\Deepak Singh\Sprint1\EmployeeInformation\DataBase\Projects.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<ProjectEntity> project = (List<ProjectEntity>)formatter.Deserialize(stream);
            stream.Close();
            return project;
        }
        /******************************* Desirializing  Role Data*******************************************/
        public static List<RoleEntity> RoleListDeSerializer()

        {
            string path = @"C:\Users\DSINGH58\Desktop\Deepak Singh\Sprint1\EmployeeInformation\DataBase\Roles.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<RoleEntity> role = (List<RoleEntity>)formatter.Deserialize(stream);
            stream.Close();
            return role;
        }

    }
}
